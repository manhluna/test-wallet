var walletconfig = {
    token_contract: "0xdf59c8ba19b4d1437d80836b45f1319d9a429eed",
    token_decimals: 4,
    token_symbol: 'IZI',
    token_name: 'IZIChain',
    etherscan_api: 'https://api.etherscan.io',
    etherscan_api_key: 'C3I51IUVVBF5MY8NUKZAK9Z2CTS2GG4PNN',
    password: '', 
    gas_price: 1,
    gas_limit: 350000
};

